# 万花谷解谜游戏

一款基于网页的解谜小游戏，玩家需要通过探索不同模块、搜索线索来解开万花谷的秘密。

## 游戏特色

- 🎮 终端风格的界面设计
- 🔍 丰富的搜索功能，支持多个关键词
- 📱 响应式设计，适配手机和电脑
- 🔒 多模块权限系统，需要解锁才能访问
- 📖 沉浸式剧情，多个结局

## 如何在其他设备上运行

### 方法一：直接打开HTML文件（推荐）

1. 将整个游戏文件夹复制到目标设备
2. 直接双击 `index.html` 文件即可开始游戏
3. **注意**：部分浏览器可能会限制本地文件的JavaScript执行，建议使用以下方法二

### 方法二：使用简易本地服务器

#### Windows系统（使用Python）

1. 确保已安装Python（推荐Python 3.x）
2. 打开命令提示符或PowerShell
3. 切换到游戏文件夹目录：
   ```bash
   cd f:\小游戏1
   ```
4. 启动本地服务器：
   ```bash
   python -m http.server 8000
   ```
5. 在浏览器中访问：`http://localhost:8000/index.html`

#### Mac/Linux系统

1. 打开终端
2. 切换到游戏文件夹目录：
   ```bash
   cd /path/to/小游戏1
   ```
3. 启动本地服务器：
   ```bash
   python3 -m http.server 8000
   ```
4. 在浏览器中访问：`http://localhost:8000/index.html`

### 方法三：使用Node.js（如果已安装）

1. 确保已安装Node.js
2. 全局安装http-server：
   ```bash
   npm install -g http-server
   ```
3. 切换到游戏文件夹目录：
   ```bash
   cd /path/to/小游戏1
   ```
4. 启动服务器：
   ```bash
   http-server -p 8000
   ```
5. 在浏览器中访问：`http://localhost:8000/index.html`

## 游戏玩法

1. **用户登录**：
   - 账号：`suqingci`
   - 密码：`PENZAI`
   - 登录后解锁"注水论坛"和"监控回放"模块

2. **游客登录**：
   - 点击"游客登录"解锁"失物招领"模块

3. **搜索功能**：
   - 支持搜索关键词：万花谷、苏清辞、萧策、唐影、曲蛊月、噬心蛊、隐元会、400-3829-5678

4. **监控回放**：
   - 输入密码：`2010001`解锁监控回放模块
   - 查看不同地点的监控信息

5. **案件调查**：
   - 搜索"400-3829-5678"进入安保中心
   - 提交线索，找出真凶

## 文件结构

```
小游戏1/
├── index.html          # 主页面
├── search.html         # 搜索结果页面
├── wuhuagu.html        # 万花谷页面
├── suqingci.html       # 苏清辞页面
├── xiaoce.html         # 萧策页面
├── tangying.html       # 唐影页面
├── quguyue.html        # 曲蛊月页面
├── shixingu.html       # 噬心蛊页面
├── yinyuanhui.html     # 隐元会页面
├── panda.html          # 熊猫页面
├── security-center.html# 安保中心页面
├── water-forum.html    # 注水论坛页面
├── lost-and-found.html # 失物招领页面
├── monitoring-playback.html # 监控回放页面
├── hot-activities.html # 热门活动页面
├── specialty-encyclopedia.html # 特产百科页面
├── endings1.html       # 结局页面1（飞不出的蝴蝶）
├── endings2.html       # 结局页面2（杀手的职责）
├── endings3.html       # 结局页面3（天才的堕落）
├── endings4.html       # 结局页面4（迷雾未明）
└── README.md           # 本说明文件
```

## 技术栈

- HTML5
- CSS3
- JavaScript
- localStorage（本地存储）

## 注意事项

- 游戏完全在本地运行，无需联网
- 建议使用Chrome、Firefox、Edge等现代浏览器
- 手机端建议使用竖屏模式体验
- 登录状态会在查看结局后重置

## 联系信息

如有问题，请联系万花谷安保中心：400-3829-5678
